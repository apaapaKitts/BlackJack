package CARDS;

public class AbsurdSuitException extends RuntimeException {
}

