package CARDS;

public class AbsurdRankException extends RuntimeException {
}
